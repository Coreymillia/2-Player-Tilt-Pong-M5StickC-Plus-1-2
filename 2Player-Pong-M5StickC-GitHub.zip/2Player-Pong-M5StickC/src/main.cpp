#include <M5Unified.h>
#include <WiFi.h>
#include <WiFiUdp.h>

// Game settings
int DISPLAY_WIDTH = 240;
int DISPLAY_HEIGHT = 135;
int scores[] = {0, 0};

// Network settings
const char* ssid = "M5Pong_Host";
const char* password = "m5stick123";
const int localPort = 8888;
const int remotePort = 8888;

WiFiUDP udp;
IPAddress remoteIP;
bool isHost = false;
bool isConnected = false;
unsigned long lastHeartbeat = 0;
unsigned long lastSyncTime = 0;

// Game modes
enum GameMode {
  WAITING_CONNECTION,
  PLAYING,
  PAUSED
};
GameMode currentMode = WAITING_CONNECTION;

// Player configuration (determined by role)
bool isPlayerLeft = true; // Host controls left paddle, client controls right

unsigned long lastFrameTime = 0;

// Tilt sensitivity settings
float tiltSensitivity = 100.0; // Increased for better responsiveness
float tiltOffset = 0.0; // Calibration offset

struct Ball
{
  float speed;
  float x;
  float y;
  int radius;
  float dx;
  float dy;
  float prevX, prevY;
} ball = {3, DISPLAY_WIDTH / 2.0, DISPLAY_HEIGHT / 2.0, 3, 4, 4, DISPLAY_WIDTH / 2.0, DISPLAY_HEIGHT / 2.0};

struct Paddle
{
  int x;
  int y;
  int width;
  int height;
  int prevY;
} leftPaddle = {5, DISPLAY_HEIGHT / 2 - 20, 5, 40, DISPLAY_HEIGHT / 2 - 20},
  rightPaddle = {DISPLAY_WIDTH - 10, DISPLAY_HEIGHT / 2 - 20, 5, 40, DISPLAY_HEIGHT / 2 - 20};

// Network message structure
struct GameMessage {
  uint8_t type; // 0=paddle_pos, 1=ball_sync, 2=score_update, 3=heartbeat
  float data1;
  float data2;
  float data3;
  uint32_t timestamp;
};

void resetBall(int direction)
{
  ball.x = DISPLAY_WIDTH / 2.0;
  ball.y = DISPLAY_HEIGHT / 2.0;
  ball.speed = 3;
  ball.dy = (rand() % 2 > 0.5 ? 1 : -1) * ball.speed;
  ball.dx = direction * ball.speed;
}

// Network functions
void setupWiFi() {
  M5.Display.fillScreen(TFT_BLACK);
  M5.Display.setCursor(10, 10);
  
  // Clean WiFi state first
  WiFi.disconnect(true);
  WiFi.mode(WIFI_STA);
  delay(500);
  
  // Try to connect as client first
  M5.Display.println("Searching for host...");
  WiFi.begin(ssid, password);
  
  unsigned long startTime = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - startTime < 8000) { // Increased timeout
    delay(500);
    M5.Display.print(".");
  }
  
  if (WiFi.status() == WL_CONNECTED) {
    // Connected as client
    isHost = false;
    isPlayerLeft = false; // Client controls right paddle
    M5.Display.println("\nConnected as Client!");
    M5.Display.print("IP: ");
    M5.Display.println(WiFi.localIP());
    
    // Find host IP (assume .1 for simplicity, or could scan)
    remoteIP = WiFi.gatewayIP();
    
    udp.begin(localPort);
    // Don't set isConnected=true here, wait for actual communication
  } else {
    // Disconnect from failed connection attempt
    WiFi.disconnect(true);
    delay(500);
    
    // Become host
    isHost = true;
    isPlayerLeft = true; // Host controls left paddle
    M5.Display.println("\nBecoming Host...");
    
    // Configure hotspot with explicit settings for better compatibility
    WiFi.mode(WIFI_AP);
    bool apResult = WiFi.softAP(ssid, password, 1, 0, 4); // channel 1, not hidden, max 4 clients
    
    if (apResult) {
      M5.Display.println("Hotspot created!");
    } else {
      M5.Display.println("Hotspot FAILED!");
    }
    
    remoteIP = IPAddress(192, 168, 4, 2); // Expected client IP
    
    M5.Display.print("Host IP: ");
    M5.Display.println(WiFi.softAPIP());
    M5.Display.println("Waiting for client...");
    
    udp.begin(localPort);
    
    // Give hotspot time to stabilize
    delay(1000);
  }
  
  delay(2000);
  M5.Display.fillScreen(TFT_BLACK);
  currentMode = WAITING_CONNECTION;
}

void sendMessage(uint8_t type, float data1 = 0, float data2 = 0, float data3 = 0) {
  if (!isConnected && !isHost) return;
  
  GameMessage msg;
  msg.type = type;
  msg.data1 = data1;
  msg.data2 = data2;
  msg.data3 = data3;
  msg.timestamp = millis();
  
  udp.beginPacket(remoteIP, remotePort);
  udp.write((uint8_t*)&msg, sizeof(msg));
  udp.endPacket();
}

void receiveMessages() {
  int packetSize = udp.parsePacket();
  if (packetSize == sizeof(GameMessage)) {
    GameMessage msg;
    udp.read((uint8_t*)&msg, sizeof(msg));
    
    switch (msg.type) {
      case 0: // Paddle position
        // Host receives client paddle data, Client receives host paddle data  
        if (isHost) {
          // Host received right paddle position from client
          rightPaddle.prevY = rightPaddle.y;
          rightPaddle.y = (int)msg.data1;
        } else {
          // Client received left paddle position from host  
          leftPaddle.prevY = leftPaddle.y;
          leftPaddle.y = (int)msg.data1;
        }
        
        if (!isConnected) {
          isConnected = true;
          currentMode = PLAYING;
          // Clear entire screen when connected to remove "HOST: Waiting..." text
          M5.Display.fillScreen(TFT_BLACK);
          // Redraw paddles at their current positions
          M5.Display.fillRect(leftPaddle.x, leftPaddle.y, leftPaddle.width, leftPaddle.height, TFT_WHITE);
          M5.Display.fillRect(rightPaddle.x, rightPaddle.y, rightPaddle.width, rightPaddle.height, TFT_WHITE);
        }
        break;
        
      case 1: // Ball sync (only host sends this)
        if (!isHost) {
          // Update previous position before setting new position
          ball.prevX = ball.x;
          ball.prevY = ball.y;
          ball.x = msg.data1;
          ball.y = msg.data2;
          ball.dx = msg.data3;
          // ball.dy would need another message or pack differently
        }
        break;
        
      case 2: // Score update (host sends to client)
        if (!isHost) {
          scores[0] = (int)msg.data1;
          scores[1] = (int)msg.data2;
        }
        break;
        
      case 3: // Heartbeat
        lastHeartbeat = millis();
        if (!isConnected) {
          isConnected = true;
          currentMode = PLAYING;
          // Clear entire screen when connected via heartbeat too
          M5.Display.fillScreen(TFT_BLACK);
          // Redraw paddles at their current positions
          M5.Display.fillRect(leftPaddle.x, leftPaddle.y, leftPaddle.width, leftPaddle.height, TFT_WHITE);
          M5.Display.fillRect(rightPaddle.x, rightPaddle.y, rightPaddle.width, rightPaddle.height, TFT_WHITE);
        }
        break;
    }
  }
}

void calibrateTilt() {
  M5.Display.fillScreen(TFT_BLACK);
  M5.Display.setCursor(10, 40);
  M5.Display.println("Hold device level");
  M5.Display.println("Press A to calibrate");
  
  while (!M5.BtnA.wasPressed()) {
    M5.update();
    delay(10);
  }
  
  // Take several readings for average
  float sumY = 0;
  for (int i = 0; i < 10; i++) {
    M5.Imu.update(); // Update IMU before reading!
    auto imu_data = M5.Imu.getImuData();
    sumY += imu_data.accel.y;
    delay(50);
  }
  tiltOffset = sumY / 10.0;
  
  M5.Display.println("Calibrated!");
  delay(1000);
}

int getTiltPaddlePosition() {
  // Update IMU data first!
  M5.Imu.update();
  auto imu_data = M5.Imu.getImuData();
  float tiltY = imu_data.accel.y - tiltOffset;
  
  // Convert tilt to paddle position (inverted for natural feel)
  int paddlePos = (DISPLAY_HEIGHT / 2) - (tiltY * tiltSensitivity);
  
  // Constrain to screen bounds
  paddlePos = constrain(paddlePos, 0, DISPLAY_HEIGHT - 40); // 40 is paddle height
  
  return paddlePos;
}

void movePaddle(Paddle *paddle, int y)
{
  // Update previous position BEFORE changing current position
  paddle->prevY = paddle->y;
  paddle->y = y;
  if (paddle->y < 0) {
    paddle->y = 0;
  }
  if (paddle->y + paddle->height > DISPLAY_HEIGHT) {
    paddle->y = DISPLAY_HEIGHT - paddle->height;
  }
}

void drawPaddles() {
  // Only redraw paddles if they actually moved to minimize artifacts
  static int lastLeftY = -1, lastRightY = -1;
  
  // Left paddle
  if (leftPaddle.y != lastLeftY) {
    if (lastLeftY != -1) {
      // Clear old position with generous buffer
      M5.Display.fillRect(leftPaddle.x - 2, lastLeftY - 5, leftPaddle.width + 4, leftPaddle.height + 10, TFT_BLACK);
    }
    // Draw new position
    M5.Display.fillRect(leftPaddle.x, leftPaddle.y, leftPaddle.width, leftPaddle.height, TFT_WHITE);
    lastLeftY = leftPaddle.y;
  }
  
  // Right paddle  
  if (rightPaddle.y != lastRightY) {
    if (lastRightY != -1) {
      // Clear old position with generous buffer
      M5.Display.fillRect(rightPaddle.x - 2, lastRightY - 5, rightPaddle.width + 4, rightPaddle.height + 10, TFT_BLACK);
    }
    // Draw new position
    M5.Display.fillRect(rightPaddle.x, rightPaddle.y, rightPaddle.width, rightPaddle.height, TFT_WHITE);
    lastRightY = rightPaddle.y;
  }
}

void resetPaddles() {
  // Clear old positions
  M5.Display.fillRect(leftPaddle.x, leftPaddle.y, leftPaddle.width, leftPaddle.height, TFT_BLACK);
  M5.Display.fillRect(rightPaddle.x, rightPaddle.y, rightPaddle.width, rightPaddle.height, TFT_BLACK);
  
  // Reset to center positions
  leftPaddle.prevY = leftPaddle.y;
  rightPaddle.prevY = rightPaddle.y;
  leftPaddle.y = DISPLAY_HEIGHT / 2 - 20;
  rightPaddle.y = DISPLAY_HEIGHT / 2 - 20;
  
  // Draw new positions
  drawPaddles();
}

void handleInput()
{
  M5.update();
  
  if (currentMode != PLAYING) {
    if (M5.BtnA.wasPressed()) {
      if (currentMode == WAITING_CONNECTION) {
        // Try to reconnect or start game
        if (isHost) {
          currentMode = PLAYING; // Host can start alone for testing
        }
      }
    }
    return;
  }
  
  // Get tilt-based paddle position
  int newPaddlePos = getTiltPaddlePosition();
  
  if (isPlayerLeft) {
    // Control left paddle
    if (newPaddlePos != leftPaddle.y) {
      movePaddle(&leftPaddle, newPaddlePos);
      // Send position to remote player (HOST sends to CLIENT)
      sendMessage(0, newPaddlePos);
    }
  } else {
    // Control right paddle  
    if (newPaddlePos != rightPaddle.y) {
      movePaddle(&rightPaddle, newPaddlePos);
      // Send position to remote player (CLIENT sends to HOST)
      sendMessage(0, newPaddlePos);
    }
  }
  
  // Button controls for backup/debugging
  if (M5.BtnA.isPressed()) {
    if (isPlayerLeft) {
      movePaddle(&leftPaddle, leftPaddle.y - 3);
      sendMessage(0, leftPaddle.y);
    } else {
      movePaddle(&rightPaddle, rightPaddle.y - 3);
      sendMessage(0, rightPaddle.y);
    }
  }
  if (M5.BtnB.isPressed()) {
    if (isPlayerLeft) {
      movePaddle(&leftPaddle, leftPaddle.y + 3);
      sendMessage(0, leftPaddle.y);
    } else {
      movePaddle(&rightPaddle, rightPaddle.y + 3);
      sendMessage(0, rightPaddle.y);
    }
  }
}

void moveBall()
{
  // Only host calculates ball physics
  if (!isHost) return;
  
  ball.prevX = ball.x;
  ball.prevY = ball.y;
  ball.x += ball.dx;
  ball.y += ball.dy;

  // Bounce off top and bottom
  if (ball.y + ball.radius > DISPLAY_HEIGHT || ball.y - ball.radius < 0) {
    ball.dy *= -1;
  }
  
  // Left paddle collision
  if (ball.x - ball.radius < leftPaddle.x + leftPaddle.width &&
      ball.x + ball.radius > leftPaddle.x &&
      ball.y - ball.radius < leftPaddle.y + leftPaddle.height &&
      ball.y + ball.radius > leftPaddle.y) {
    ball.dx = abs(ball.dx); // Always go right after hitting left paddle
    ball.speed++;
    
    float collidePoint = ball.y - (leftPaddle.y + leftPaddle.height / 2);
    collidePoint = collidePoint / (leftPaddle.height / 2);
    float angleRad = (PI / 4) * collidePoint;
    ball.dy = ball.speed * sin(angleRad);
  }
  
  // Right paddle collision
  if (ball.x - ball.radius < rightPaddle.x + rightPaddle.width &&
      ball.x + ball.radius > rightPaddle.x &&
      ball.y - ball.radius < rightPaddle.y + rightPaddle.height &&
      ball.y + ball.radius > rightPaddle.y) {
    ball.dx = -abs(ball.dx); // Always go left after hitting right paddle
    ball.speed++;
    
    float collidePoint = ball.y - (rightPaddle.y + rightPaddle.height / 2);
    collidePoint = collidePoint / (rightPaddle.height / 2);
    float angleRad = (PI / 4) * collidePoint;
    ball.dy = ball.speed * sin(angleRad);
  }

  // Scoring
  if (ball.x + ball.radius > DISPLAY_WIDTH) {
    // Left player scores
    scores[0]++;
    M5.Display.fillRect(DISPLAY_WIDTH / 4, 10, 50, 15, TFT_BLACK);
    M5.Display.setCursor(DISPLAY_WIDTH / 4, 10);
    M5.Display.printf("%d", scores[0]);
    M5.Speaker.tone(8000, 200);
    sendMessage(2, scores[0], scores[1]); // Send score update
    delay(1000);
    resetPaddles();
    resetBall(-1);
  }
  
  if (ball.x - ball.radius < 0) {
    // Right player scores
    scores[1]++;
    M5.Display.fillRect((3 * DISPLAY_WIDTH) / 4, 10, 50, 15, TFT_BLACK);
    M5.Display.setCursor((3 * DISPLAY_WIDTH) / 4, 10);
    M5.Display.printf("%d", scores[1]);
    M5.Speaker.tone(8000, 200);
    sendMessage(2, scores[0], scores[1]); // Send score update
    delay(1000);
    resetPaddles();
    resetBall(1);
  }
  
  // Send ball sync to client (reduced frequency)
  if (millis() - lastSyncTime > 50) { // ~20 FPS sync (was 30 FPS)
    sendMessage(1, ball.x, ball.y, ball.dx);
    lastSyncTime = millis();
  }
}

void draw()
{
  // Only draw ball and scores during gameplay
  if (currentMode == PLAYING) {
    // Clear previous ball position
    M5.Display.fillCircle((int)ball.prevX, (int)ball.prevY, ball.radius, TFT_BLACK);
    // Draw current ball position
    M5.Display.fillCircle((int)ball.x, (int)ball.y, ball.radius, TFT_WHITE);
    
    // Draw both paddles (this will show remote paddle movement!)
    drawPaddles();
    
    // Draw scores (clear area first to prevent text overlap)
    M5.Display.fillRect(DISPLAY_WIDTH / 4 - 10, 10, 30, 15, TFT_BLACK);
    M5.Display.fillRect((3 * DISPLAY_WIDTH) / 4 - 10, 10, 30, 15, TFT_BLACK);
    M5.Display.setCursor(DISPLAY_WIDTH / 4, 10);
    M5.Display.printf("%d", scores[0]);
    M5.Display.setCursor((3 * DISPLAY_WIDTH) / 4, 10);
    M5.Display.printf("%d", scores[1]);
    
    // Show role indicator (small text at bottom)
    M5.Display.fillRect(0, DISPLAY_HEIGHT - 15, DISPLAY_WIDTH, 15, TFT_BLACK);
    M5.Display.setCursor(5, DISPLAY_HEIGHT - 12);
    M5.Display.setTextSize(1);
    if (isHost) {
      M5.Display.printf("HOST-LEFT");
    } else {
      M5.Display.printf("CLIENT-RIGHT"); 
    }
  } else if (currentMode == WAITING_CONNECTION) {
    // Only show connection status when not playing
    M5.Display.setCursor(10, 50);
    M5.Display.setTextColor(TFT_YELLOW);
    if (isHost) {
      M5.Display.println("HOST: Waiting...");
    } else {
      M5.Display.println("CLIENT: Connecting...");
    }
    M5.Display.setTextColor(TFT_WHITE);
  }
}

void setup()
{
  auto cfg = M5.config();
  M5.begin(cfg);
  
  // Auto-detect device type and configure accordingly
  const char* deviceName;
  switch (M5.getBoard()) {
    case m5::board_t::board_M5StickCPlus:
      deviceName = "M5StickC Plus1";
      break;
    case m5::board_t::board_M5StickCPlus2:
      deviceName = "M5StickC Plus2";
      break;
    default:
      deviceName = "M5StickC Unknown";
      break;
  }
  
  // Display setup (M5Unified handles device differences automatically)
  M5.Display.setRotation(3);
  M5.Display.fillScreen(TFT_BLACK);
  
  // Show device detection
  M5.Display.setCursor(10, 10);
  M5.Display.setTextColor(TFT_GREEN);
  M5.Display.printf("Detected: %s", deviceName);
  delay(2000); // Show for 2 seconds
  
  M5.Display.fillScreen(TFT_BLACK);
  int textsize = M5.Display.height() / 60;
  if (textsize == 0) textsize = 1;
  M5.Display.setTextSize(textsize);
  M5.Display.setTextColor(TFT_WHITE);
  
  randomSeed(analogRead(0));
  
  // Initialize IMU
  M5.Imu.begin();
  
  // Calibrate tilt controls
  calibrateTilt();
  
  // Setup WiFi networking
  setupWiFi();
  
  // Draw initial game state
  M5.Display.fillScreen(TFT_BLACK);
  M5.Display.fillRect(leftPaddle.x, leftPaddle.y, leftPaddle.width, leftPaddle.height, TFT_WHITE);
  M5.Display.fillRect(rightPaddle.x, rightPaddle.y, rightPaddle.width, rightPaddle.height, TFT_WHITE);
  
  // Send initial heartbeat
  sendMessage(3);
}

void loop()
{
  unsigned long currentTime = millis();
  if (currentTime - lastFrameTime < 16) return; // ~60 FPS
  lastFrameTime = currentTime;
  
  // Handle network communication
  receiveMessages();
  
  // Send periodic heartbeat
  if (currentTime - lastHeartbeat > 1000) {
    sendMessage(3); // heartbeat
    lastHeartbeat = currentTime;
  }
  
  // Handle input (tilt controls)
  handleInput();
  
  // Move ball (only on host, client gets updates via network)
  if (currentMode == PLAYING && isHost) {
    moveBall();
  }
  
  // Draw everything (both host and client draw)
  draw();
}